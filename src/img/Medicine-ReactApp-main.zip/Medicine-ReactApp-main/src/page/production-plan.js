import React from 'react'
import Layout from '../layout/layout'

const ProductionPlan = ()=>{
  return (
    <Layout>
      <h1>Kế hoạch sản xuất</h1>
    </Layout>
  )
}

export default ProductionPlan;
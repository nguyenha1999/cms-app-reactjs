import React from 'react'

const StepsConstructive = ()=>{
  return (
    <>
      <h1>Quy trình sản xuất ở đây</h1>
    </>
  )
}

export default StepsConstructive
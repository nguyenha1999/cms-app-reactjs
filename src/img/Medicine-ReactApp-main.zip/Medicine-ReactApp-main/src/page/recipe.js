import React from 'react'

const Recipe = ()=>{
  return (
    <>
      <h1>thành phần của sản phẩm ở đây, sử dụng dạng tree của thầy cho</h1>
    </>
  )
}

export default Recipe
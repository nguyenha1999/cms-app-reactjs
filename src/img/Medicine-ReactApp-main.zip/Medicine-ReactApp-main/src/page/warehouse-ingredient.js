import React from 'react'
import Layout from '../layout/layout'
const WareHouse = () => {
  return (
    <Layout>
      kho thành phần
    </Layout>
  )
}

export default WareHouse
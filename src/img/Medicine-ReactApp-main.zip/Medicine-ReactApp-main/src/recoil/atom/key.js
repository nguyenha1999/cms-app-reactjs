//định nghĩa ky của từng atom ( key là khác nhau và riêng biệt )

export const getMedicineData = 'getMedicineData';